# Effective Java Examples

This are the souces from the book "Effective Java Second Edition", written by Joshua Bloch.

They are unmodifed, except the package names.

The original source are downloaded from http://java.sun.com/docs/books/effective/index.html, but are no longer provided.

