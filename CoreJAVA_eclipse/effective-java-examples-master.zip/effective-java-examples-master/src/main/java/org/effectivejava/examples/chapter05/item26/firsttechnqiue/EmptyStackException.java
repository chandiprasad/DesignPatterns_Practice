package org.effectivejava.examples.chapter05.item26.firsttechnqiue;

public class EmptyStackException extends RuntimeException {
}
