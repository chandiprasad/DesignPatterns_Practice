// Class hierarchy replacement for a tagged class
package org.effectivejava.examples.chapter04.Item20.hierarchy;

abstract class Figure {
	abstract double area();
}
