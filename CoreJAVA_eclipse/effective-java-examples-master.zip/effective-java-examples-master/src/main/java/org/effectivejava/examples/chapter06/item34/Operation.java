// Emulated extensible enum using an interface - Page 165
package org.effectivejava.examples.chapter06.item34;

public interface Operation {
	double apply(double x, double y);
}
