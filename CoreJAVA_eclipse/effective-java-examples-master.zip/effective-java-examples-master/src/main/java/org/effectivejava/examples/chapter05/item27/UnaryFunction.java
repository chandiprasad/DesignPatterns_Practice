// Unary function - page 131
package org.effectivejava.examples.chapter05.item27;

public interface UnaryFunction<T> {
	T apply(T arg);
}
