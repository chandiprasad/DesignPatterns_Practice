package org.effectivejava.examples.chapter03.item08.composition;

public enum Color {
	RED, ORANGE, YELLOW, GREEN, BLUE, INDIGO, VIOLET
}
