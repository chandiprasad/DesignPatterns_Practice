// What does this program do? - Page 222
package org.effectivejava.examples.chapter07.item49;

public class Unbelievable {
	static Integer i;

	public static void main(String[] args) {
		if (i == 42)
			System.out.println("Unbelievable");
	}
}