package org.effectivejava.examples.chapter02.item06;

public class EmptyStackException extends IllegalStateException {
}
