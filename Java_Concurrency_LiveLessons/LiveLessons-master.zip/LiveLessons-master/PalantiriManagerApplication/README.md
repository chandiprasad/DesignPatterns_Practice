This folder contains source code for the following two apps that
implement pattern-oriented variants of the
PalantiriManagerApplication:

original -- This folder provides the original implementation of this
app from my [Java
Concurrency](http://www.dre.vanderbilt.edu/~schmidt/LiveLessons/CPiJava/)
LiveLesson tutorial.

updated -- This folder provides an updated version of my LiveLessons
tutorial that uses Java 8 features, such as lambdas, method references,
Streams, and CompletableFutures:
