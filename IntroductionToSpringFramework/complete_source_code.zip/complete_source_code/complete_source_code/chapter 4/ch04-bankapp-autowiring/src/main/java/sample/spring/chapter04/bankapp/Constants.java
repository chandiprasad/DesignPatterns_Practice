package sample.spring.chapter04.bankapp;

public class Constants {
	public static final String EVENT_SENDER_CLASS_PROPERTY = "eventSenderClass";
}
