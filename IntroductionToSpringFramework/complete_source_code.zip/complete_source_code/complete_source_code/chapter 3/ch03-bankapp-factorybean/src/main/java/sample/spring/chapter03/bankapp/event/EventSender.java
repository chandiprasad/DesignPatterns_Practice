package sample.spring.chapter03.bankapp.event;

public interface EventSender {
	void sendEvent(Event e);
}
